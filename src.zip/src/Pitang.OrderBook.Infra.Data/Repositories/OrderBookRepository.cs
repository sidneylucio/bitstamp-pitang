﻿using MongoDB.Driver;
using Pitang.OrderBook.Domain.Entities;
using Pitang.OrderBook.Domain.Interfaces;
using System.Threading.Tasks;

namespace Pitang.OrderBook.Infra.Data.Repositories;

public class OrderBookRepository : IOrderBookRepository
{
    private readonly IMongoCollection<OrderBookMessage> _messagesCollection;

    public OrderBookRepository(IMongoClient mongoClient)
    {
        var database = mongoClient.GetDatabase("OrderBookDb");
        _messagesCollection = database.GetCollection<OrderBookMessage>("OrderBookMessages");
    }

    public async Task SaveMessageAsync(OrderBookMessage message)
    {
        try
        {
            await _messagesCollection.InsertOneAsync(message);
        }
        catch(Exception ex)
        {

        }
       
    }
}
