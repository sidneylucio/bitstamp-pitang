﻿using MediatR;
using Pitang.OrderBook.Application.Commands;

namespace Pitang.OrderBook.Api.Services
{
    public class LiveOrderBookBackgroundService : BackgroundService
    {
        private readonly ILogger<LiveOrderBookBackgroundService> _logger;
        private readonly IMediator _mediator;

        public LiveOrderBookBackgroundService(ILogger<LiveOrderBookBackgroundService> logger, IMediator mediator)
        {
            _logger = logger;
            _mediator = mediator;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            _logger.LogInformation("SimpleBackgroundService iniciado.");

            while (!stoppingToken.IsCancellationRequested)
            {
                _logger.LogInformation("SimpleBackgroundService em execução às: {time}", DateTimeOffset.Now);

                await _mediator.Send(new LiveOrderBookCommand());

                await Task.Delay(5000, stoppingToken);
            }

            _logger.LogInformation("SimpleBackgroundService foi encerrado.");
        }
    }
}
