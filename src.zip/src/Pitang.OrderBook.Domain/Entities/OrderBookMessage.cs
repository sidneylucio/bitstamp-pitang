﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace Pitang.OrderBook.Domain.Entities;

public class OrderBookMessage
{
    [BsonId]
    [BsonRepresentation(BsonType.ObjectId)]
    public string Id { get; set; }

    [BsonElement("timestamp")]
    public DateTime Timestamp { get; set; }

    [BsonElement("message")]
    public required string Message { get; set; }
}
