﻿using Pitang.OrderBook.Domain.Entities;

namespace Pitang.OrderBook.Domain.Interfaces;

public interface IOrderBookRepository
{
    Task SaveMessageAsync(OrderBookMessage message);
}
