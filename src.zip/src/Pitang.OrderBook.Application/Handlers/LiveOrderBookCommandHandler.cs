﻿using MediatR;
using Pitang.OrderBook.Application.Commands;
using Pitang.OrderBook.Domain.Entities;
using Pitang.OrderBook.Domain.Interfaces;
using Pitang.OrderBook.Infra.CrossCutting.Websocket;
using System.Threading.Channels;

namespace Pitang.OrderBook.Application.Handlers
{
    public class LiveOrderBookCommandHandler : IRequestHandler<LiveOrderBookCommand>
    {
        private readonly IBitstampWebSocketClient _webSocketClient;
        private readonly IOrderBookRepository _orderBookRepository;
        private readonly Channel<string> _messageChannel;
        private readonly CancellationTokenSource _cts = new();

        public LiveOrderBookCommandHandler(IBitstampWebSocketClient webSocketClient, IOrderBookRepository orderBookRepository)
        {
            _webSocketClient = webSocketClient;
            _orderBookRepository = orderBookRepository;
            _messageChannel = Channel.CreateUnbounded<string>();

            _webSocketClient.OnMessageReceived += async message =>
            {
                await _messageChannel.Writer.WriteAsync(message);
            };

            _ = Task.Run(() => ProcessMessages(_cts.Token));
        }

        public async Task Handle(LiveOrderBookCommand request, CancellationToken cancellationToken)
        {
            await _webSocketClient.StartAsync();
        }

        private async Task ProcessMessages(CancellationToken token)
        {
            await foreach (var message in _messageChannel.Reader.ReadAllAsync(token))
            {
                var orderBookMessage = new OrderBookMessage
                {
                    Timestamp = DateTime.UtcNow,
                    Message = message
                };

                await _orderBookRepository.SaveMessageAsync(orderBookMessage);
            }
        }

        public async Task StopAsync()
        {
            _cts.Cancel();
            await _webSocketClient.StopAsync();
        }
    }
}
