﻿using MediatR;

namespace Pitang.OrderBook.Application.Commands;

public class LiveOrderBookCommand : IRequest
{
    public LiveOrderBookCommand() { }
}